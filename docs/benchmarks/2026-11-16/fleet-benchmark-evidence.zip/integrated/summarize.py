import csv,math,pathlib,statistics,sys
def p(xs,q):
    return sorted(xs)[math.ceil(len(xs)*q)-1]
for path in map(pathlib.Path,sys.argv[1:]):
    text=path.read_text().splitlines()
    rows=[x for x in text if x[:1].isdigit()]
    if not text[-1].startswith("END ") or not rows: continue
    data=list(csv.reader(rows))
    idx=2 if 'live=true' in next(k for k in text if k.startswith('BENCH ')) else 4
    t=[float(x[idx]) for x in data]
    print(path.name,len(t),*(round(p(t,q),3) for q in (.5,.95,.99)),sum(x>1000/30 for x in t),text[-1])
