import diplomacy.sim.Battle;
import diplomacy.sim.DemonstrationBattle;
import diplomacy.shipyard.Shipyard;
import diplomacy.tech.TechnologyCatalog;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class BattleStepBench {
    private static Battle create(int perSide, TechnologyCatalog catalog) {
        if (perSide == 200) return DemonstrationBattle.create(catalog);
        return Battle.duel(20261111L + perSide, perSide,
                Shipyard.starter(Battle.Faction.TERRAN, Shipyard.Hull.DREADNOUGHT),
                Shipyard.starter(Battle.Faction.DRAXIAN, Shipyard.Hull.DREADNOUGHT), catalog);
    }

    public static void main(String[] args) throws Exception {
        var catalog = TechnologyCatalog.loadDefault();
        int ticks = 480;
        for (int round = 0; round < 2; round++) {
            for (int perSide : new int[] {1, 16, 200}) {
                var battle = create(perSide, catalog);
                long[] ns = new long[ticks];
                for (int i = 0; i < ticks; i++) {
                    long before = System.nanoTime();
                    battle.step();
                    ns[i] = System.nanoTime() - before;
                }
                if (round == 0) continue;
                var path = Path.of(args[0] + "-" + perSide + ".csv");
                try (var out = Files.newBufferedWriter(path)) {
                    out.write("tick,step_ns\n");
                    for (int i = 0; i < ticks; i++) out.write((i + 1) + "," + ns[i] + "\n");
                }
                Arrays.sort(ns);
                System.out.printf(Locale.ROOT, "side=%d ticks=%d hits=%d lost=%d fp=%016x p50=%.4f p95=%.4f p99=%.4f max=%.4f%n",
                        perSide, battle.tick, battle.hitCount, battle.destructions, battle.fingerprint(),
                        ns[239]/1e6, ns[455]/1e6, ns[475]/1e6, ns[479]/1e6);
            }
        }
    }
}
