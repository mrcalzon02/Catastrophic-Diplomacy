package diplomacy.client;
import diplomacy.net.BattleConnection;
final class SnapshotAdapter {
    long prepare(BattleConnection.Snapshot snap, RemoteShipInterpolation clock, RemoteFleetMirrors mirrors) {
        var frame = RemoteEntityPresentation.from(snap);
        if (snap.tick() != clock.tick()) clock.observe(snap.tick(), frame.ships());
        clock.advance(1f/60);
        var scene = mirrors.present(clock, false);
        long result = scene.ships().size() + scene.ships().get(0).weaponEmitters.size();
        for (var motion : frame.missiles()) result += (int)motion.x();
        for (var motion : frame.ballistics()) result += (int)motion.x();
        for (var motion : frame.crafts()) result += (int)motion.x();
        return result;
    }
}
