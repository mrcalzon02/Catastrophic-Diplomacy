package diplomacy.client;
import diplomacy.net.BattleConnection;
import java.lang.management.ManagementFactory;
import java.nio.file.*;
import java.util.*;

public final class PresentationBench {
    public static void main(String[] args) throws Exception {
        var rows = Files.readAllLines(Path.of(args[0]));
        var decode = BattleConnection.class.getDeclaredMethod("decodeEntities", List.class, int.class);
        decode.setAccessible(true);
        @SuppressWarnings("unchecked")
        var entities = (List<BattleConnection.Entity>) decode.invoke(null, rows, 2);
        var cpu = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
        var clock = new RemoteShipInterpolation();
        var mirrors = new RemoteFleetMirrors();
        var adapter = new SnapshotAdapter();
        int tick = 0;
        long guard = 0;
        System.out.println("window,samples,cpu_ns,alloc_bytes,wall_ns,guard");
        for (int window = -3; window < 10; window++) {
            long cpuNs = 0, allocations = 0, wallNs = 0;
            for (int message = 0; message < 20; message++) {
                tick += 3;
                var snapshot = new BattleConnection.Snapshot("bench",tick,0,rows,entities);
                // Measure only the network client's presentation preparation, before GL.
                long startCpu = cpu.getCurrentThreadCpuTime(), startBytes = cpu.getCurrentThreadAllocatedBytes();
                long start = System.nanoTime();
                for (int screen = 0; screen < 6; screen++)
                    guard += adapter.prepare(snapshot, clock, mirrors);
                wallNs += System.nanoTime() - start;
                cpuNs += cpu.getCurrentThreadCpuTime() - startCpu;
                allocations += cpu.getCurrentThreadAllocatedBytes() - startBytes;
            }
            if (window >= 0) System.out.printf("%d,120,%d,%d,%d,%d%n",window,cpuNs,allocations,wallNs,guard);
        }
    }
}
