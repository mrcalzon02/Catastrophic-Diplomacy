import diplomacy.net.BattleConnection;
import hbnet.Hbnet;
import java.io.*;
import java.net.Socket;
import java.nio.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;

// Count Java reads at the socket-stream boundary; TLS and the kernel may further buffer reads.
public class ReadCountProbe {
    static class Reads extends ByteArrayInputStream {
        long singles, bulk;
        Reads(byte[] data) { super(data); }
        public synchronized int read() { singles++; return super.read(); }
        public synchronized int read(byte[] b, int off, int n) { bulk++; return super.read(b,off,n); }
    }
    static class Fixture extends Socket {
        final Reads stream;
        Fixture(byte[] data) { stream = new Reads(data); }
        public InputStream getInputStream() { return stream; }
        public OutputStream getOutputStream() { return OutputStream.nullOutputStream(); }
        public void setSoTimeout(int x) {}
        public void close() {}
    }
    public static void main(String[] args) throws Exception {
        List<String> rows = Files.readAllLines(Path.of(args[0]));
        String hash = Hbnet.hash(String.join("\n",rows).getBytes(StandardCharsets.US_ASCII));
        List<String> frames = new ArrayList<>();
        frames.add("WELCOME|2|fixture|0|2479|0");
        frames.add("SNAP|90|2479|"+rows.size());
        frames.addAll(rows);
        frames.add("END|90|"+hash);
        var wire = new ByteArrayOutputStream();
        Hbnet.writeBatch(wire,frames);
        var socket = new Fixture(wire.toByteArray());
        var ctor = BattleConnection.class.getDeclaredConstructor(Socket.class,boolean.class);
        ctor.setAccessible(true);
        try (BattleConnection client = ctor.newInstance(socket,false)) {
            long deadline = System.nanoTime()+5_000_000_000L;
            while(client.connected() && System.nanoTime()<deadline) Thread.sleep(1);
            if(client.connected() || client.snapshot()==null || !client.snapshot().entities().equals(rows)) throw new AssertionError("wire acceptance");
            System.out.printf("entities=%d wireBytes=%d singleReads=%d bulkReads=%d%n",
                rows.size(),wire.size(),socket.stream.singles,socket.stream.bulk);
        }
    }
}
