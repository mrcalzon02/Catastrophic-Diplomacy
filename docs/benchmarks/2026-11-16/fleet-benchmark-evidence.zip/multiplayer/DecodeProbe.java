package diplomacy.net;

import diplomacy.server.BattleServer;
import java.nio.file.*;
import java.util.*;
import java.lang.management.ManagementFactory;

/** Capture actual decoded authoritative rows, or replay their exact entity payloads. */
public class DecodeProbe {
    public static void main(String[] args) throws Exception {
        Path file = Path.of(args[1]);
        if ("capture".equals(args[0])) {
            try (BattleServer host = BattleServer.openLan("127.0.0.1", 0, 2479L, 200);
                 BattleConnection client = BattleConnection.openLan("127.0.0.1", host.port(), false)) {
                long deadline = System.nanoTime() + 30_000_000_000L;
                while ((client.snapshot() == null || client.snapshot().tick()<90) && System.nanoTime()<deadline) Thread.sleep(1);
                var snap = client.snapshot();
                if(snap==null || snap.tick()<90)throw new AssertionError("snapshot deadline");
                Files.write(file, snap.entities());
                System.out.println("capture tick="+snap.tick()+" entities="+snap.entities().size());
            }
            return;
        }
        List<String> rows = Files.readAllLines(file);
        List<BattleConnection.Entity> reference = BattleConnection.decodeEntities(rows, 2);
        var mx = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
        for(int round=-12; round<5; round++) {
            long cpu = mx.getCurrentThreadCpuTime(), allocated = mx.getCurrentThreadAllocatedBytes(), n = 0;
            for(int i=0; i<24; i++) {
                var decoded = BattleConnection.decodeEntities(rows, 2);
                n += decoded.size();
                if(!decoded.equals(reference))throw new AssertionError("entity mismatch");
            }
            if(round>=0)System.out.printf(Locale.ROOT, "%d,%d,%.3f,%d%n",round,n,(mx.getCurrentThreadCpuTime()-cpu)/1e6,mx.getCurrentThreadAllocatedBytes()-allocated);
        }
    }
}
