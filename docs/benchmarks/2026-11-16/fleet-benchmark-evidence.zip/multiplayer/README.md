# Two-client multiplayer benchmark

The server and two production BattleConnection clients use actual TCP sockets on loopback in one Java 17 process. This includes TLS as a separate functional test in accept.log. Timing CSVs use the OPEN_LAN entry point. No WAN, mobile display, or hardware GPU timing is represented.

The authoritative server spawns 200 Terran and 200 Draxian starter corvettes, seed 2479. Two clients negotiate v2. Ticks 90–225 inclusive give 46 scheduled snapshots per seat at the 30 Hz simulation rate divided by the server's three-tick broadcast interval. The controller polls the latest fully checked, decoded snapshot at a nominal 1 ms. Polling and scheduling add error. Both seats issue orders after the timed range and require both acknowledgments. Tests used Java 17, a two-core affinity mask, a 300 MiB starting heap and 650 MiB cap. Each CSV is a fresh JVM. The reader CPU column measures both reader threads' CPU between the boundary snapshots. Their aggregate is insensitive to thread ordering when boundaries coincide; poll/scheduling differences can affect each run. CPU is not end-to-end client time. The server's maximum step covers the process lifetime and excludes snapshot serialization. bytesQueued is cumulative across that match including startup, not a measured bandwidth.

For 32-ship companion trials the same procedure uses 16 ships per team.

Rows begin with ROW, followed by seat, authoritative tick, simulation hash, time since previous published snapshot (ms), decoded entity count, skipped three-tick updates. PASS rows give total ships, observed snapshots across both seats, ticks with a matching peer hash, decoded entities across observations, skipped updates, combined reader CPU (ms), server queued bytes, maximum host simulation step (ms), time for both final order ACKs (ms), and final host tick. The first measured snapshot has no preceding timed interval. summary.py prints per-run nearest-rank quantiles across the two seats.

base1–3 use c0435a33da3b9b38e591d6474fbf881f51b961e1. buf1–3 add only the shared input buffer. fit1–3 additionally reuse parsed fittings within each snapshot. final1–3 use the combined changes (simulation, networking and presentation). Both base and candidate use the same authenticated hardpoints resource baked from the real ship art. sha256: d6d1e9b020a99ea9e70f81d778a5e72c2dc2b3ccad5edd619159c702c43299fc.

## Reproduction

At each revision, compile core and server classes with the project JVM and bake game resources using the project's Gradle tasks (Java 17). From the game repository root on Linux:

```bash
gradle :server:classes :core:processResources
CLASSES="server/build/classes/java/main:core/build/classes/java/main:core/build/resources/main"
JAVA_HOME=/path/to/jdk17 BENCH_CPUS=4,5 /path/to/run-lan.sh rerun "$CLASSES" 200 135
python3 /path/to/summary.py
```

Set BENCH_CPUS to two available isolated logical CPUs on the same machine for all compared revisions. Keep other workloads off those cores while sampling.

DecodeProbe.java replays the exact 494-entity snapshot.rows captured from baseline tick 90 on production sockets, SHA-256 7f47d3f17e810c472ec3257b8a9831498be7fa93147ef03ff62b4db2a61fcee4. It measures only the production entity decoder plus an equality check on the same decoded reference each time. Each block decodes the payload 24 times. Twelve warmup blocks precede five measured blocks. CSV columns are block, entities, calling-thread CPU milliseconds, allocated bytes. To reproduce, use the same CLASSES and real capture:

```bash
javac --release 17 -cp "$CLASSES" -d /tmp/decoder-classes /path/to/DecodeProbe.java
taskset -c 4,5 java -Xbatch -Xms300m -Xmx650m -XX:ActiveProcessorCount=2 -cp "/tmp/decoder-classes:$CLASSES" diplomacy.net.DecodeProbe replay /path/to/snapshot.rows
```

accept.log exercises production LAN, pinned TLS with reconnect, lobby ownership/policy, terminal outcomes, and malformed snapshots through the repository's own test entry points.

ReadCountProbe.java supplies the captured entity rows as one valid framed v2 exchange to the production BattleConnection handshake and reader. It verifies the complete accepted payload and counts calls made at a counting socket-input fixture, including EOF. This identifies buffering behavior. It does not count kernel system calls or promise a particular packet count. Compile as for DecodeProbe and run ReadCountProbe with the path to snapshot.rows.

Run verify.py with the baseline and candidate CSV paths for the same fleet size to compare every observed seat/tick's authoritative hash and decoded entity count.

Across the three 400-ship baseline runs the median reader CPU was 415.407 ms. The input-buffer-only median was 274.282 ms. Adding per-snapshot fittings reuse lowered the median to 175.142 ms. The combined candidate including simulation changes measured 189.049 ms. All four groups transmitted identical observed game states. Median within-run p95 arrival time for the combined candidate was 214.6 ms versus the baseline's 206.4 ms. The lower reader CPU therefore did not remove the observed host/client delivery stalls.

The median of within-JVM block medians for the fixed payload decoder was 49.484 ms versus 23.606 ms in baseline and fittings-optimized JVMs, respectively. Allocations were 92,790,800 versus 42,208,784 bytes per 24 decodes. The counted-input fixture used 2,489 versus 16 underlying Java read calls.
