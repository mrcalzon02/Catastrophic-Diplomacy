"""Reconcile two-client authoritative ticks, hashes, entity counts, and benchmark receipts."""
import csv
import sys
from pathlib import Path

def receipt(filename):
    with Path(filename).open() as stream:
        rows = list(csv.reader(stream))
    passes = [r for r in rows if r and r[0] == "PASS"]
    assert len(passes) == 1, filename
    passed = passes[0]
    assert int(passed[2]) == 92 and int(passed[3]) == 46 and int(passed[5]) == 0, passed
    entities = {(int(r[1]), int(r[2])): (int(r[3]), int(r[5]))
                for r in rows if r and r[0] == "ROW"}
    expected = {(seat, tick) for seat in (0, 1) for tick in range(93, 226, 3)}
    assert entities.keys() == expected, (filename, entities.keys() ^ expected)
    for tick in range(93, 226, 3):
        assert entities[(0, tick)] == entities[(1, tick)], (filename, tick)
    return entities

if __name__ == "__main__":
    base = receipt(sys.argv[1])
    for filename in sys.argv[2:]:
        assert receipt(filename) == base, filename
    print(f"PASS matched {len(base)} seat/tick hashes and entity counts per file in {len(sys.argv)-1} files")
