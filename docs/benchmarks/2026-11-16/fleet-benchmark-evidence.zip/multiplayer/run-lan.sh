#!/bin/bash
set -euo pipefail
# Run from the game repository root after compilation and baking approved hardpoints.
# Example: run-lan.sh label path/to/classes:core/build/resources/main 200 135
label=$1
classes=$2
ships=$3
ticks=$4
root=$(cd "$(dirname "$0")" && pwd)
jdk=${JAVA_HOME:?Set JAVA_HOME to a Java 17 JDK}
mkdir -p "$root/probe"
"$jdk/bin/javac" --release 17 -cp "$classes" -d "$root/probe" "$root/LanProbe.java"
taskset -c "${BENCH_CPUS:-4,5}" "$jdk/bin/java" -Xms300m -Xmx650m -XX:ActiveProcessorCount=2 -cp "$root/probe:$classes" LanProbe "$ships" "$ticks" > "$root/$label.csv"
tail -1 "$root/$label.csv"
