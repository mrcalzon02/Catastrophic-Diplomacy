import csv,statistics,sys
from pathlib import Path
root=Path(__file__).parent
for p in sorted(root.glob("*.csv")):
    rows=list(csv.reader(p.open()))
    stats=[r for r in rows if r and r[0]=="PASS"]
    if not stats:continue
    durations=sorted(float(r[4]) for r in rows if r and r[0]=="ROW")
    take=lambda q: durations[__import__('math').ceil(q*len(durations))-1]
    _,ships,seen,matched,entities,skipped,reader_cpu,total_bytes,step_max,ack_latency,tick=stats[-1]
    print(f"{p.stem:12s} ships={ships:>3s} intervals={len(durations):3d} common={matched:>3s} skipped={skipped:>2s} p50/95/99/max={take(.5):.1f}/{take(.95):.1f}/{take(.99):.1f}/{take(1):.1f}ms reader_cpu_ms={reader_cpu} ack={ack_latency}ms")
