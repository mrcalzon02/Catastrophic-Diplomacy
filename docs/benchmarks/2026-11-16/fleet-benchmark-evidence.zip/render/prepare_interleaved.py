"""Write temporary desktop fixture sources for the within-process balanced A/B."""
import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("repository", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
client = args.repository / "game/src/main/java/diplomacy/client"

def replace(source, before, after):
    if source.count(before) != 1:
        raise ValueError(f"Source changed. Expected one occurrence of {before}")
    return source.replace(before, after)

shader = (client / "ShieldMaterialShader.java").read_text()
shader = replace(shader, "private final boolean batched;", """
    private final boolean batched;
    static boolean trialBatched;
    private final ShaderProgram reference = new ShaderProgram(VERTEX,FRAGMENT);""")
shader = replace(shader, "return program;}", "return trialBatched?program:reference;}")
shader = shader.replace("program.setUniform", "program().setUniform")
(args.output / "ShieldMaterialShader.java").write_text(shader)

sprites = (client / "TerranPlaceholderSprites.java").read_text()
for original, changed in (
    ("sheet==null?new Texture[DirectionalDefense.Facing.values().length]:null", "new Texture[DirectionalDefense.Facing.values().length]"),
    ("shellSheet==null?new Texture[DirectionalDefense.Facing.values().length]:null", "new Texture[DirectionalDefense.Facing.values().length]"),
    ("else layers[face.ordinal()]=linearTexture(pix);", "layers[face.ordinal()]=linearTexture(pix);"),
    ("else built[face.ordinal()]=linearTexture(pixels);", "built[face.ordinal()]=linearTexture(pixels);"),
    ("if(sectors.atlas==null){", "if(sectors.atlas==null||!ShieldMaterialShader.trialBatched){"),
):
    sprites = replace(sprites, original, changed)
(args.output / "TerranPlaceholderSprites.java").write_text(sprites)

fixture = (args.repository / "desktop/src/test/java/diplomacy/desktop/DesktopFrameBenchmark.java").read_text()
fixture = replace(fixture, "private int index;", "private int index; private Field trial;")
fixture = replace(fixture, "if(live){\n                method", """
            trial=Class.forName("diplomacy.client.ShieldMaterialShader").getDeclaredField("trialBatched");
            trial.setAccessible(true);
            if(live){
                method""")
fixture = replace(fixture, "if(profiler!=null)profiler.reset();", """
        try { trial.setBoolean(null,(index%4==1||index%4==2) ^ (index/20%2==1)); }
        catch (ReflectiveOperationException error) {throw new IllegalStateException(error);}
        if(profiler!=null)profiler.reset();""")
(args.output / "DesktopFrameBenchmark.java").write_text(fixture)
