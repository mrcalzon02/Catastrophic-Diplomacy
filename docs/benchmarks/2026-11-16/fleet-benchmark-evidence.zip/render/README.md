# Desktop render evidence

Java 17, native LWJGL3 OpenGL 3.3, Mesa llvmpipe (LLVM 19.1.7, 256 bits), Xvfb, 1280×720, vsync off, two llvmpipe worker threads, CPU affinity 6–8. The normal game, core and renderer use source c0435a33da3b9b38e591d6474fbf881f51b961e1, with the candidate shield code overlaid for attribution. Bundled textures, native libraries and audio came from cd-v0.1.5-dev.699 Linux x64. Percentiles use nearest rank. Deterministic tests supply a 1/60-second input delta, displayed 1× speed, and pre-advance 90 authoritative ticks. Completed drawing measures elapsed time from game.render() start through glFinish(), excluding swap, capture and file writing. Intervals in the live trial include the normal LWJGL swap loop. The two PNGs are captured outside the measured rendering interval in the fixed test. The live trial uses the real input delta, without forced GL completion or framebuffer readback.

### Within-process comparison

After 40 warming frames, measure 400 frames, 200 per path. The fixture selects individual face textures or the single-sampler atlas within one process and one battle. For zero-based frame index i, the atlas is used when (i % 4 in (1, 2)) != ((i // 20) % 2 == 1). This alternates both paths in short blocks and rotates which one receives physics ticks. The battle has 400 deployed ships. The ordinary fleet-size selector shows its default 16v16 in this fixture. The fixed test holds the initial ordinary battlefield backdrop. At the beginning of warmup the battle has 968 hits, 31 missiles and 428 ballistic shells. It finishes at tick 112 with 1,196 hits, state 46d2d3f5f1843ba8. GL counters were disabled for timings.

| Fixed frame, 400 ships | Original p50 / p95 / p99 ms | Atlas p50 / p95 / p99 ms |
| --- | --- | --- |
| CPU submission | 36.80 / 70.86 / 120.31 | 11.67 / 41.04 / 88.15 |
| Frame through GL completion | 76.73 / 121.13 / 164.49 | 68.21 / 108.78 / 163.62 |

Separate 80-frame GLProfiler runs with 18 warmup frames measured median actual GL draw calls 1,973 → 213 and median texture binds 2,137 → 377. Use those logs for counts because the profiler adds overhead to every GL call. The original pass diagnostic saw 1,837 SpriteBatch draws attributable to the hull and shields together at tick 90. Weapon effects, procedural sky and additive glow still take substantial time on software GL. An eight-sampler shield shader also reduced submission work but increased completed-frame time in its interleaved comparison. Its log is retained. It was discarded.

### Advancing 16v16 escort

At seed 6003, pre-advance to first hit with surviving missile or ballistic. Both runs begin tick 127, state 0b1a7631cbd3662e, 32 live missiles, 50 ballistic shells, 1 hit. Both finish tick 136, state a6e6cb8ca80f36d6, 3 hits. Warm 18 actual frames and measure 80. Frame interval p50/p95 was 29.921/45.7391 ms original, 28.7429/43.2630 ms with atlas. Frames over 33.33 ms went from 26/80 to 16/80. These are separate runs on shared software-rendered hardware. Physical GPU and phone performance requires measurement there.

### Images

The original and atlas frame-18 and frame-97 captures differ on exactly 228 pixels per frame out of 921,600. Every changed channel differs by one unit on the 0–255 scale. Source-art sampling retained the material inputs, draw order and local UV for recharge scanning. Atlas interpolation changes rounding. A forced compilation failure of the atlas shader selected the original separate-texture path. Its frame-18 PNG matched the original byte-for-byte. See png-sha256.txt.

### Repeat

On supported desktop OpenGL with staged game assets run the manual Gradle task:

    gradle :desktop:combatFrameBenchmark -Dbench.output=/absolute/path/to/frames
    gradle :desktop:combatFrameBenchmark -Dbench.counters=true
    gradle :desktop:combatFrameBenchmark -Dbench.live=true -Dbench.engaged=true

Use the same CPU/GPU, driver, 1280×720, game assets, and JVM. For the alternating A/B invoke prepare_interleaved.py with the candidate repository and an empty temporary source directory. It generates three test-only Java sources. Compile those with javac --release 17 against the regular game and desktop runtime classpaths. Put the generated classes first on that classpath and invoke diplomacy.desktop.DesktopFrameBenchmark with -Dbench.warm=40 -Dbench.frames=400. Source generation was checked and compiled. The generated renderer allocates both original and atlas art before warmup ends, leaving the rest of the renderer and the battle state common. The four PNGs alongside the repository report came from separate original and final production-path runs. Its before/after tick-90 files correspond to frame 18 and its tick-94 files to frame 97.
