package diplomacy.client;
import java.nio.file.*;
public class ExportShader {
    public static void main(String[] args) throws Exception {
        Path dir=Path.of(args[0]);
        Files.writeString(dir.resolve("single.vert"),ShieldMaterialShader.VERTEX);
        Files.writeString(dir.resolve("single.frag"),ShieldMaterialShader.FRAGMENT);
        Files.writeString(dir.resolve("batched.vert"),ShieldMaterialShader.LAYER_VERTEX);
        Files.writeString(dir.resolve("batched.frag"),ShieldMaterialShader.LAYER_FRAGMENT);
    }
}
