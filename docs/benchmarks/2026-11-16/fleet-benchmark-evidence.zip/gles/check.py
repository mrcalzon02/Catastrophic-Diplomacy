"""Compile and draw with both runtime shader pairs on a real offscreen ES 2.0 context."""
import ctypes as C, hashlib, os, pathlib
os.environ.update(EGL_PLATFORM='surfaceless', MESA_GLES_VERSION_OVERRIDE='2.0', LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='1')
E=C.CDLL('libEGL.so.1')
P=C.c_void_p; I=C.c_int; U=C.c_uint; F=C.c_float; S=C.c_char_p; B=C.c_ubyte
def egl(name, result, *args):
    f=getattr(E,name); f.restype=result; f.argtypes=args; return f
def ints(*v): return (I*len(v))(*v)
get=egl('eglGetProcAddress',P,S)
d=egl('eglGetDisplay',P,P)(None); assert d
assert egl('eglInitialize',U,P,P,P)(d,None,None)
assert egl('eglBindAPI',U,U)(0x30a0)
cfg=P(); count=I()
assert egl('eglChooseConfig',U,P,P,P,I,P)(d,ints(0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038),C.byref(cfg),1,C.byref(count)) and count.value
surf=egl('eglCreatePbufferSurface',P,P,P,P)(d,cfg,ints(0x3057,64,0x3056,64,0x3038))
ctx=egl('eglCreateContext',P,P,P,P,P)(d,cfg,None,ints(0x3098,2,0x3038))
assert surf and ctx and egl('eglMakeCurrent',U,P,P,P,P)(d,surf,surf,ctx)
def gl(name,result,*args):
    return C.CFUNCTYPE(result,*args)(get(('gl'+name).encode()))
def gs(name): return gl('GetString',S,U)(name).decode()
print(gs(0x1f02),gs(0x1f01))
def program(prefix):
    p=gl('CreateProgram',U)()
    for ext,typ in [('vert',0x8b31),('frag',0x8b30)]:
        sh=gl('CreateShader',U,U)(typ); src=S(pathlib.Path(prefix+'.'+ext).read_bytes())
        gl('ShaderSource',None,U,I,P,P)(sh,1,C.byref(src),None)
        gl('CompileShader',None,U)(sh); ok=I()
        gl('GetShaderiv',None,U,U,P)(sh,0x8b81,C.byref(ok)); buf=C.create_string_buffer(8192)
        gl('GetShaderInfoLog',None,U,I,P,P)(sh,len(buf),None,buf); assert ok.value,buf.value
        gl('AttachShader',None,U,U)(p,sh)
    gl('LinkProgram',None,U)(p); ok=I(); gl('GetProgramiv',None,U,U,P)(p,0x8b82,C.byref(ok))
    buf=C.create_string_buffer(8192); gl('GetProgramInfoLog',None,U,I,P,P)(p,len(buf),None,buf); assert ok.value,buf.value
    return p
def sample(prefix):
    p=program(prefix); gl('UseProgram',None,U)(p)
    uniform=lambda s:gl('GetUniformLocation',I,U,S)(p,s.encode())
    gl('UniformMatrix4fv',None,I,I,B,P)(uniform('u_projTrans'),1,0,(F*16)(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1))
    gl('Uniform1i',None,I,I)(uniform('u_texture'),0)
    gl('Uniform1f',None,I,F)(uniform('u_tick'),42)
    import numpy as np
    ids=(U*9)(); gl('GenTextures',None,I,P)(9,ids)
    def texture(id,pixels):
        gl('BindTexture',None,U,U)(0xde1,id)
        h,w,_=pixels.shape
        gl('TexImage2D',None,U,I,I,I,I,U,U,P)(0xde1,0,0x1908,w,h,0,0x1908,0x1401,S(pixels.tobytes()))
        for k in [0x2800,0x2801]: gl('TexParameteri',None,U,U,I)(0xde1,k,0x2601)
        for k in [0x2802,0x2803]: gl('TexParameteri',None,U,U,I)(0xde1,k,0x812f)
    sheet=np.zeros((484,386,4),dtype=np.uint8)
    for layer in range(8):
        w,h=192,192 if layer<4 else 288
        face=layer%4; row=0 if layer<4 else 194
        y,x=np.indices((h,w))
        a=np.zeros((h,w,4),dtype=np.uint8)
        for ch in range(4): a[:,:,ch]=(45+layer*19+ch*17+x//4+y//4)%256
        if face==0:
            a[h//2:]=0; sheet[row:row+h//2+1,0:w]=a[:h//2+1]
        elif face==1:
            a[:,w//2:]=0; sheet[row:row+h,192:289]=a[:,:97]
        elif face==2:
            a[:h//2]=0; sheet[row+h//2+1:row+h+2,0:w]=a[h//2-1:]
        else:
            a[:,:w//2]=0; sheet[row:row+h,289:386]=a[:,95:]
        texture(ids[layer],a)
    texture(ids[8],sheet)
    attrib=lambda s:gl('GetAttribLocation',I,U,S)(p,s.encode())
    color=attrib('a_color');gl('VertexAttrib4f',None,U,F,F,F,F)(color,.4,.8,.6,.8)
    pos=attrib('a_position'); uv=attrib('a_texCoord0')
    for loc in [pos,uv]:gl('EnableVertexAttribArray',None,U)(loc)
    vertices=(F*8)(-1,-1,1,-1,-1,1,1,1)
    gl('VertexAttribPointer',None,U,I,U,B,I,P)(pos,2,0x1406,0,0,vertices)
    frames=[]
    for scan in (0,1):
        gl('Uniform1f',None,I,F)(uniform('u_scan'),scan)
        for layer in range(8):
            offset=layer*2 if prefix=='batched' else 0
            if prefix=='single':gl('BindTexture',None,U,U)(0xde1,ids[layer])
            texuv=(F*8)(offset,0,offset+1,0,offset,1,offset+1,1)
            gl('VertexAttribPointer',None,U,I,U,B,I,P)(uv,2,0x1406,0,0,texuv)
            gl('DrawArrays',None,U,I,I)(5,0,4)
            pix=(B*(64*64*4))()
            gl('ReadPixels',None,I,I,I,I,U,U,P)(0,0,64,64,0x1908,0x1401,pix)
            assert gl('GetError',U)()==0
            frames.append(bytes(pix))
    return frames
before=sample('single'); after=sample('batched')
assert len(set(before))==16 and all(len(set(x))>8 for x in before)
for i,(a,b) in enumerate(zip(before,after)):
    from statistics import mean
    d=[abs(x-y) for x,y in zip(a,b)]
    print('layer',i,'max_channel_delta',max(d),'mean_channel_delta',round(mean(d),4))
    assert a==b, (i,max(d),mean(d))
    print('changed_pixel_pct',round(100*sum(any(d[j:j+4]) for j in range(0,len(d),4))/(len(d)/4),3))
print('PASS 16 byte-identical GLES2 atlas readbacks (eight layers, scan on/off); candidate SHA-256',hashlib.sha256(b''.join(after)).hexdigest())
