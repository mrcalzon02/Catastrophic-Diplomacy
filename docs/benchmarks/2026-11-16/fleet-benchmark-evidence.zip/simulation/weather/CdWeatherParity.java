import diplomacy.sim.*;
import diplomacy.tech.*;
import java.util.*;
public class CdWeatherParity {
 public static void main(String[] args)throws Exception{
  var tech=TechnologyCatalog.loadDefault();
  for(int scenario=0;scenario<3;scenario++){
   var b=scenario==0?DemonstrationBattle.create(tech):Battle.duel(20261116+scenario,24,Battle.Faction.TERRAN,Battle.Faction.CARNELIAN);
   b.configureWeather(SpaceWeather.forLevel(new int[]{1,2,9}[scenario]));
   b.configureRelayScanMetrics(true);
   long timeline=0,display=0;
   for(int tick=0;tick<480;tick++){
    if(scenario==1&&tick%19==0){
      var s=b.ships().get(3);
      s.x=2200-(tick%5)*500;
      s.y=1100-(tick%3)*450;
    }
    b.step();
    timeline=timeline*31+b.fingerprint();
    if(tick%41==0)for(int team=0;team<=1;team++)
        display=31*display+b.tacticalPicture(team).toString().hashCode();
   }
   System.out.printf("scenario=%d hash=%x timeline=%x tactical=%x hits=%d relay=%s%n",
           scenario,b.fingerprint(),timeline,display,b.hitCount,b.relayScanMetrics());
  }
 }
}
