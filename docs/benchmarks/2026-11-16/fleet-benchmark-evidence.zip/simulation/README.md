# Authoritative simulation CPU comparison

PairedCpuProfile loads the two compiled builds in independent class loaders inside the same Java 17 process. Each build creates the production DemonstrationBattle with seed 762244, 200 ships per side, the technology catalog, and the same 110-hull approved hardpoint bake. Each 480-tick replay starts fresh. The order of the base and candidate step alternates each tick and flips on alternate replays. The first complete pair warms both builds. The four subsequent complete pairs are measured. The harness checks equality of the production battle fingerprint after every tick and stops on the first mismatch.

CPU durations come from ThreadMXBean on the calling simulation thread. They include computation while that thread is on a CPU. Worker-thread work, background compiler time, time descheduled and rendering are outside that measurement. Each build also records monotonic elapsed step times. GC and scheduling can affect wall times on this shared host. The phase observer is installed before combat in both builds. The measured phase boundaries cover preparation, sensor networking, captains, support, projectiles and craft/cleanup. Replays are repeated measurements of one fixed deterministic scenario, not independent samples from different fights.

Run from a directory with the two core builds, production resources and the harness. Baked hardpoints must exist as hardpoints/approved-v1.txt below the resource root. The technology resource root must contain technology/. The exact hardpoint file used had SHA-256 d6d1e9b020a99ea9e70f81d778a5e72c2dc2b3ccad5edd619159c702c43299fc. Use the repository bakeApprovedHardpoints task to regenerate it.

```sh
mkdir -p harness-classes
javac --release 17 -d harness-classes PairedCpuProfile.java
taskset -c 2,3 java -XX:ActiveProcessorCount=2 -Xms640m -Xmx640m -XX:+UseSerialGC \
  -cp harness-classes PairedCpuProfile base/classes candidate/classes \
  lan/resources game/core/src/main/resources paired-cpu.csv >paired-cpu.log
```

The CSV contains paired nanoseconds for the authoritative step, step phases, elapsed step and equality-checked fingerprint. Pair 0 is warmup. Main thread CPU, including the overhead of the observer, does not measure display refreshes, GPU work, GC worker CPU or physical Android performance.

## Treatments and additional checks

* paired-cpu.csv compares the starting core (c0435a33da3b9b38e591d6474fbf881f51b961e1) against the ballistic-column change alone. The battlefield is clear. This first paired run had CPU affinity 2,3.
* combined-clear.csv compares the same starting core against both the ballistic-column change and the weather relay exclusion. Affinity is CPU 2. There are five 480-tick pairs including warmup.
* weather/combined-weather.csv compares the same starting core against both changes with level 1 asteroid weather enabled exactly as in the packaged verifier. This run uses CPU 3, five 120-tick pairs including warmup. Use weather/LevelOneWeatherCpuProfile.java in place of the clear harness.
* weather/ranked.csv isolates the relay exclusion. Both builds already include the ballistic-column change. The weather and seeds match and all tick fingerprints are checked. This earlier run had CPU affinity 2,3.
* weather/shell-experiment.csv compares a separate unshipped photon-shell interior acceptance shortcut against the ballistic-column build. It used the same asteroid workload. The shortcut passed the 104,204-case exact oracle but its timing result varied between pairs, including a worse pooled sensor p95. The shortcut was omitted from the shipped code.
* weather/CdWeatherParity.java independently runs 480 ticks in three configurations with relay counters enabled, including forced discontinuous movement on the nebula scenario. Compare its two .log files. Every combat fingerprint sequence, sampled tactical display digest and final hit count matches. For the 400-ship level 1 scenario, the legacy code executed 32,733,062 full sensor queries and the ranked code executed 11,500,093. The order of candidate visits, observed contacts selected for relay and transmitted packet stream remain deterministic.
* profiles/level-1-ballistic-hotspots.txt contains the sampled Java execution stacks from the ballistic-only build for two fresh 200-tick replays using level 1 asteroid weather. The text export contains only jdk.ExecutionSample events, up to 12 stack frames per sample. The entry point is profiles/CdWeatherSingle.java. Method samples represent activity; they are not precise duration counters.

For reproducing the isolated relay comparison, use the pre-sensor build as the first classpath, then the combined build as the second. To summarize any phase CSV, run python3 summarize.py PATH. Every retained comparison uses the same seed and resources for its two builds. Timing differences between *separate* comparison runs are not measurements of an extra optimization.
