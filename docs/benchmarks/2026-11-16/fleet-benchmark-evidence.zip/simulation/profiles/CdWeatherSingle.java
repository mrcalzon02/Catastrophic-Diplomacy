import diplomacy.sim.*;import diplomacy.tech.*;
public class CdWeatherSingle {
 public static void main(String[] args)throws Exception {
  var tech=TechnologyCatalog.loadDefault();
  for(int i=0;i<2;i++){
    var b=DemonstrationBattle.create(tech);b.configureWeather(SpaceWeather.forLevel(1));
    for(int j=0;j<200;j++)b.step();
    System.out.println(Long.toHexString(b.fingerprint()));
  }
 }
}
