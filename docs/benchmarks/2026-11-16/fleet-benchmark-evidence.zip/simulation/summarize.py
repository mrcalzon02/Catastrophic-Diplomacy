"""Summarize measured pairs, discarding pair zero (JVM warmup)."""
import csv
import math
import statistics
import sys

with open(sys.argv[1], newline="") as stream:
    rows = [r for r in csv.DictReader(stream) if int(r["pair"]) > 0]
cases = sorted({int(r["pair"]) for r in rows})
for pair in cases:
    measured = [r for r in rows if int(r["pair"]) == pair]
    print("pair", pair, "count", len(measured))
    for field in ("CpuNs", "ProjectilesCpuNs", "SensorsCpuNs"):
        for side in ("base", "candidate"):
            values = sorted(int(r[side + field]) / 1e6 for r in measured)
            print(side, field, "mean", round(statistics.mean(values), 4),
                  "median", round(statistics.median(values), 4),
                  "p95", round(values[math.ceil(.95 * len(values)) - 1], 4))
print("All measured ticks, ms of main-thread CPU")
for field in ("CpuNs", "PreparationCpuNs", "SensorsCpuNs", "CaptainsCpuNs",
              "SupportCpuNs", "ProjectilesCpuNs", "CraftCleanupCpuNs"):
    for side in ("base", "candidate"):
        values = sorted(int(r[side + field]) / 1e6 for r in rows)
        print(side, field, "mean", round(statistics.mean(values), 4),
              "median", round(statistics.median(values), 4),
              "p95", round(values[math.ceil(.95 * len(values)) - 1], 4),
              "p99", round(values[math.ceil(.99 * len(values)) - 1], 4))
