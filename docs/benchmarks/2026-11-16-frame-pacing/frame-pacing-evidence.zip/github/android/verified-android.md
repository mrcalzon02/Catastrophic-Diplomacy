# Hosted paired Android combat runs

Builds aec40264e909489083d292a499eca0b8fc7e0190 and 360f5374a65fe7c41e3f181e96089e0181afe038 produced separate APKs. The job clean-installed each APK in baseline, candidate, candidate, baseline order on one Android 10 x86_64 API 29 emulator using Google SwiftShader (GLES 3.0). Landscape captures are 1920×1080. The inherited performance-diagnostic.json device descriptor hardcodes Android 34: the captured system fingerprint, renderer and workflow select API 29. Each verifier passed at 499 ticks, 26 rendered frames, with 400 textured ships, 12,403 shots, 6,767 hits and 8,890 impacts. Each early and late capture differs and its SHA-256 matches the corresponding trial receipt.

| Trial | Render callback mean, ms | Simulation/frame, ms | Non-simulation/frame, ms | Captains/tick, ms | Sensors/tick, ms |
| --- | ---: | ---: | ---: | ---: | ---: |
| base-1 | 2510.56 | 1608.27 | 902.29 | 28.66 | 44.14 |
| candidate-1 | 1927.82 | 1053.71 | 874.10 | 10.11 | 34.23 |
| candidate-2 | 1878.29 | 1028.56 | 849.72 | 10.08 | 32.93 |
| base-2 | 2442.37 | 1567.50 | 874.87 | 27.56 | 43.47 |

The median of the two mean render durations per build fell from 2476.47 to 1903.05 ms (23.2%). The median of the two single-trial worst durations fell from 5814.72 to 5229.50 ms. The counters bracket gameplay rendering with System.nanoTime and include wall time inside that callback; no compositor display intervals, GPU timer, or physical mobile FPS was sampled. The 8× verification mode deliberately processes many simulation steps per frame. There were 26 frames in each result, below the 180-frame rolling counter reset. The raw trace supports comparison of this identical stress workload; it cannot establish ordinary handheld frame pacing.

The immutable GitHub artifact ZIP SHA-256 is 4b6c05ec9ea919b7b791eed6512660a1db9becc9902da4214169388769f07e38. Artifact ID 14281179345; workflow run 43977721018 attempt 1; Android job 133685896139. All 35 archive entries were extracted after checking GitHub's byte count and SHA-256 and validating ZIP CRCs. All four trial APK digests match apks.sha256. Full per-trial fields, real device identification and aggregate medians are in verified-summary.json. All files originally in the GitHub artifact are retained as received.
