from pathlib import Path
import csv
import math
import re
import statistics as st

root = Path(__file__).parent
def quantile(xs,q):
    return sorted(xs)[math.ceil(len(xs)*q)-1]
for f in sorted((root/'wire').glob("*.log")):
    s=f.read_text().splitlines()
    data=[line.split(",") for line in s if re.match(r'^\d+,\d+,',line)]
    if not data:continue
    ticks=[int(r[1]) for r in data]
    intervals=[float(r[2]) for r in data]
    submit=[float(r[3]) for r in data]
    thread=[float(r[4]) for r in data]
    print(f"{f.stem:22s} frames={len(ticks):2d} ticks={ticks[0]}..{ticks[-1]} "
          f"interval median/p95={st.median(intervals):7.2f}/{quantile(intervals,.95):7.2f}ms "
          f"submit median/p95={st.median(submit):7.2f}/{quantile(submit,.95):7.2f}ms "
          f"CPU median/p95={st.median(thread):7.2f}/{quantile(thread,.95):7.2f}ms "
          f"repeat={sum(a==b for a,b in zip(ticks,ticks[1:]))}")
    for line in s:
        if line.startswith(("FIXED ","PASS ","HOST ")):print("   ",line)
for f in sorted((root/'mirror').glob("mirror-*.csv")):
    rows=list(csv.reader(f.open()))
    print(f.name, f"CPU median={st.median(int(r[2])/int(r[1]) for r in rows)/1000:.2f}us/snapshot",
          f"bytes median={st.median(int(r[3])/int(r[1]) for r in rows):.0f}/snapshot")
