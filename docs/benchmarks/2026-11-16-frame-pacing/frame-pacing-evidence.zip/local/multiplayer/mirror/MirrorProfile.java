package diplomacy.client;
import diplomacy.net.BattleConnection;
import java.nio.file.*;
import java.lang.management.ManagementFactory;
import java.util.*;
public class MirrorProfile {
    public static void main(String[] args)throws Exception{
        var rows=Files.readAllLines(Path.of(args[0]));
        var decode=BattleConnection.class.getDeclaredMethod("decodeEntities",List.class,int.class);
        decode.setAccessible(true);
        List<?> decoded=(List<?>)decode.invoke(null,rows,2);
        var ships=decoded.stream().filter(BattleConnection.ShipEntity.class::isInstance)
                .map(BattleConnection.ShipEntity.class::cast).toList();
        var interpolation=new RemoteShipInterpolation();
        var mirrors=new RemoteFleetMirrors();
        var mx=(com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();
        long tick=0;
        for(int window=-5;window<8;window++){
            long cpu=0,bytes=0,guard=0;
            for(int i=0;i<50;i++){
                interpolation.observe(tick+=3,ships);interpolation.advance(.1f);
                long beforeCpu=mx.getCurrentThreadCpuTime(),beforeBytes=mx.getCurrentThreadAllocatedBytes();
                var result=mirrors.present(interpolation,false);
                cpu+=mx.getCurrentThreadCpuTime()-beforeCpu;
                bytes+=mx.getCurrentThreadAllocatedBytes()-beforeBytes;
                for(var ship:result.ships())guard+=ship.weaponEmitters.size();
            }
            if(window>=0)System.out.println(window+",50,"+cpu+","+bytes+","+guard);
        }
    }
}
