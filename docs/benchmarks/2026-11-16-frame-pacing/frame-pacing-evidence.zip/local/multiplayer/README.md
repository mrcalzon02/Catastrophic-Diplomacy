# Connected multiplayer frame and fitting measurements

The host and graphical client are separate Java 17 processes on the same Linux machine. The host runs production BattleServer.openLan over actual TCP. The native desktop client enters the Multiplayer menu, connects one rendered player seat and one independent headless seat, confirms both server-issued team assignments, issues both orders, and waits for acknowledgments. Timed calls execute CatastrophicGame.render, MultiplayerPanel.draw, the authoritative fleet renderer, and the Scene2D overlay. There is no simulated client fight. The different progress of real network games across revisions is expected. This is trusted loopback rather than a WAN latency test. Frame timings use Mesa llvmpipe at 1280×720 with vsync off. Actual hardware acceleration and physical mobile input/display are separate measurements.

Base is aec4026. Candidate is the renderer/mirror change in 84e391a. Benchmark baseline CatastrophicGame, RemoteFleetMirrors and TerranPlaceholderSprites classes matched SHA-256 against fresh Java 17 recompilation from aec4026. All local timing runs used the same release-packaged game assets. The host uses CPU 0 and the client / llvmpipe CPUs 1–2 with one llvmpipe worker.

Files in wire contain the per-frame counts and timestamps as CSV lines within raw process logs. Timed samples start after both orders are acknowledged, the host has reached at least tick 90, and the local graphics warmup has run. interval_ms covers the elapsed interval between calls through the real swap path. submit_ms measures wall time within game.render, including driver calls. render_thread_cpu_ms is the calling thread's consumed CPU during game.render. rendered_tick identifies the actual authoritative tick presented. latest_entity_count samples the most recently accepted snapshot as the render call ends. PASS records the first/last presented tick, the latest tick for the second player, both acknowledgments, and framebuffer CRC. HOST records complete process high-water battle.step time and cumulatively queued bytes. Continuity and CPU distributions can vary substantially on this software-rendered machine. Prefix base or after identifies the build. Suffix A or B identifies a fresh production client/server JVM pair with GL instrumentation disabled. Suffix count enables GLProfiler, adding overhead; those runs are used for GL work counts, not frame-rate claims. The host JFR was recorded separately during one candidate counter run and is not used for comparative timing.

The fixed rows are the 494 typed entities of a prior real transmitted snapshot (400 corvettes, seed 2479, tick 90; SHA-256 7f47d3f17e810c472ec3257b8a9831498be7fa93147ef03ff62b4db2a61fcee4). The fixture feeds this identical payload to the production drawRemoteBattle after all live timing, from a new session, twice to settle presentation and counter state. FIXED draws/binds/vertices and the associated CRC refer to this controlled frame. GLProfiler's vertex count is the reported count of vertex/index submissions, not a count of unique mesh points. The zoom factors .65 and .35 use the normal remote camera center. In the matched payload, the former includes all 400 hulls under the game's conservative frustum test.

## Reproduce

Compile NetworkFrameBenchmark.java from desktop/src/test/java with desktop/test, game, core, server, desktop LWJGL3 and native runtime jars on the classpath. Include core's authenticated hardpoints and the release desktop runtime assets; the benchmark launches its child JVM with the same classpath. Run from a fresh temporary directory so the created test network profile is isolated. A Java 17 JDK and OpenGL 3.3 display are required, or Xvfb with llvmpipe for a software baseline. These commands assume JAVA_HOME and CLASSPATH have been configured as above.

```bash
"$JAVA_HOME/bin/java" -Xmx650m -XX:ActiveProcessorCount=2 -Dbench.net.ships=200 -Dbench.net.frames=45 -Dbench.net.warm=12 -Dbench.net.zoom=.65 -Dbench.net.proofRows=/absolute/path/to/wire/snapshot.rows diplomacy.desktop.NetworkFrameBenchmark
"$JAVA_HOME/bin/java" -Xmx650m -XX:ActiveProcessorCount=2 -Dbench.net.ships=200 -Dbench.net.frames=32 -Dbench.net.warm=12 -Dbench.net.zoom=.35 -Dbench.net.counters=true -Dbench.net.output=/existing/dir/controlled.png -Dbench.net.proofRows=/absolute/path/to/wire/snapshot.rows diplomacy.desktop.NetworkFrameBenchmark
```

The optional Linux bench.net.hostCpu pins the child JVM using taskset, and bench.net.hostJfr records a Java Flight Recorder profile of the dedicated host. Do not enable counters/JFR for primary timing pairs.

The mirror subdirectory contains a second comparison independent of network arrival and graphics. MirrorProfile.java decodes the same captured payload once, advances the actual RemoteShipInterpolation and times only RemoteFleetMirrors.present on a new authoritative tick. Each of eight measured blocks has 50 snapshots; five warm-up blocks are discarded. The output columns are block, snapshots, thread CPU ns, allocated bytes, and an emitter-count guard. Compile against the matching game/core classes and run diplomacy.client.MirrorProfile with the path to wire/snapshot.rows; JVM flags were -Xbatch -XX:ActiveProcessorCount=1 -Xms128m -Xmx256m. PresentationBench.java also tests the larger complete preparation path for six rendered frames per received snapshot; those raw files start with base- or after-. Run summarize.py for the per-run metrics.

## Results from the local comparison

At camera zoom .35, identical captured bytes produced identical 1280×720 RGBA pixels in both builds (CRC b8ffbfaf, PNG SHA-256 3b03d721e42e772dc71077a80e84af8ed723a7da357e879b8f97a8a6e1dc0347). The production renderer submitted 21,669 versus 10,383 vertices/indices, 8 versus 6 draw calls, and 11 versus 9 texture bindings. At zoom .65 the screenshot CRC was 6c0f6439 in both builds, with 8 draws and 11 binds in both.

Live figures below use the median of two per-run statistics per build with GL counters off:

| 400-ship two-seat workload | Baseline | Candidate |
| --- | ---: | ---: |
| Zoom .35 render-thread CPU median / p95 | 6.32 / 11.50 ms | 5.13 / 7.92 ms |
| Zoom .35 game.render wall median / p95 | 31.35 / 80.27 ms | 24.33 / 50.13 ms |
| Zoom .35 start-to-start median / p95 | 230.07 / 404.57 ms | 314.42 / 505.20 ms |
| Zoom .65 render-thread CPU median / p95 | 6.37 / 9.88 ms | 5.71 / 11.51 ms |
| Zoom .65 game.render wall median / p95 | 41.18 / 67.84 ms | 38.47 / 81.95 ms |
| Zoom .65 start-to-start median / p95 | 238.08 / 363.36 ms | 184.68 / 504.99 ms |

The matched-payload snapshot fitting refresh used 99.26 versus 26.30 microseconds of render-thread CPU and 353,328 versus 42,928 allocated bytes per 400-ship update. This compares two JVMs per build. These savings did not establish improved full connected frame delivery on the local software renderer. The host profile and uncontrolled real-time arrival variations are retained separately.
