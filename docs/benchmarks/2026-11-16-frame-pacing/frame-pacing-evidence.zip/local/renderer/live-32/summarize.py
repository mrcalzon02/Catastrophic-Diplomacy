import csv, re, math, statistics, sys
from pathlib import Path

def quantile(values,q):
    return sorted(values)[math.ceil(q*len(values))-1]

def summarize(path):
    content=path.read_text().splitlines()
    if not any(row.startswith('END tick=') for row in content): return
    points=list(csv.reader(line for line in content if re.match(r'^\d+,',line)))
    ms=[float(row[2]) for row in points]
    begin=next(row for row in content if row.startswith('BEGIN'))
    end=next(row for row in content if row.startswith('END'))
    assert 'BEGIN tick=127 state=0b1a7631cbd3662e hits=1 missiles=32 ballistics=50' in begin
    assert 'ships=32 live=true' in next(row for row in content if row.startswith('BENCH'))
    return dict(run=path.stem,n=len(ms),median=round(quantile(ms,.5),3),p95=round(quantile(ms,.95),3),p99=round(quantile(ms,.99),3),slow=sum(t>1000/60 for t in ms),slowPct=round(100*sum(t>1000/60 for t in ms)/len(ms),2),stationary=sum(row[8]=='true' for row in points),endTick=re.search(r'tick=(\d+)',end)[1],endHits=re.search(r'hits=(\d+)',end)[1])

rows=[r for path in sorted(Path(sys.argv[1]).glob(sys.argv[2])) if (r:=summarize(path))]
if rows:
    writer=csv.DictWriter(sys.stdout,rows[0].keys());writer.writeheader();writer.writerows(rows)
