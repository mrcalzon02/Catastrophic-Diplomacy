"""Generate test-only full-cell / cropped-cell switching on a shared laser renderer."""
from argparse import ArgumentParser
from pathlib import Path
ap=ArgumentParser()
ap.add_argument("repo",type=Path)
ap.add_argument("out",type=Path)
args=ap.parse_args()
s=(args.repo / "game/src/main/java/diplomacy/client/LaserRun01Fx.java").read_text()
s=s.replace("final class LaserRun01Fx","public final class LaserRun01Fx")
s=s.replace("    private static final int MAX_SHOTS=384;","""    public static boolean trialCropped;
    private final Map<Integer,Frame[]> fullFrames=new HashMap<>();
    private static final int MAX_SHOTS=384;""")
s=s.replace("            Frame[] frames=frames(image,atlas,w,h);","""            Frame[] full=new Frame[FRAMES[atlas]];
            for(int i=0;i<full.length;i++)full[i]=new Frame(new TextureRegion(image,i%COLUMNS*w,i/COLUMNS*h,w,h),0f,0f,1f,1f);
            fullFrames.put(atlas,full);
            Frame[] frames=frames(image,atlas,w,h);""")
s=s.replace("            if(frames==null)continue;","            if(frames==null)continue;\n            if(!trialCropped)frames=fullFrames.get(index);")
args.out.mkdir(parents=True,exist_ok=True)
(args.out / "LaserRun01Fx.java").write_text(s)
s=(args.repo / "desktop/src/test/java/diplomacy/desktop/DesktopFrameBenchmark.java").read_text().replace(
    "        if(profiler!=null)profiler.reset();",
    "        diplomacy.client.LaserRun01Fx.trialCropped=(index%4==1||index%4==2)^(index/20%2==1);\n        if(profiler!=null)profiler.reset();")
(args.out / "DesktopFrameBenchmark.java").write_text(s)
