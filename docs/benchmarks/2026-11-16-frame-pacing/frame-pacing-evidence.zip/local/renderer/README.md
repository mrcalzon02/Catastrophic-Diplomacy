# Pass 2 renderer comparison

Main baseline aec40264e909489083d292a499eca0b8fc7e0190 and candidate shield commit 2192df9e8b5b82a72698e155b0029a7f13d847b5. Fresh Java 17 compilation of every production core, game, desktop and server class. Linux package cd-v0.1.5-dev.699 provided identical native libraries and source assets for both. Xvfb/Mesa llvmpipe (LLVM 19.1.7, 256 bits), 1280×720, CPUs 6-8, two llvmpipe workers. No hardware GPU was attached.

The 400-ship fixture starts at tick 90, state 6ac0607c7cbdb498, with 968 hits, 31 missiles and 428 ballistic shells. Frames use the actual game renderer with 1/60 s deterministic input and the displayed 1× simulation speed. The nameplate retains its default 16v16 selector. The deployed fixture contains 400 ships. Overall GL-completed frame time is from game.render entry through glFinish, with framebuffer reads and file output excluded.

In one process across 40 warmup frames then 160 measured frames, the test alternated the original shield quads with the source-alpha clipped shield quads. Atlas samples, painter order, fragment shader, hull transforms, camera and simulation were common. Crop is active when (i % 4 in (1,2)) differs from (i // 20 % 2 == 1). Each arm receives 80 frames. The alternating phase spreads the physics ticks across both. Final tick 100, state 6cf048e24cd3294b, 1,066 hits. The first longer local attempt was externally killed during host memory pressure; results below use the complete 160-frame retry with a 576 MiB JVM heap.

| Time | Full quads p50 / p95 / p99 ms | Clipped quads p50 / p95 / p99 ms |
| --- | --- | --- |
| CPU submission | 77.881 / 241.623 / 495.615 | 76.957 / 207.743 / 758.143 |
| Through GL completion | 402.441 / 609.692 / 796.402 | 338.920 / 554.135 / 833.266 |

The shared software-rendered host was under heavy load. The within-run comparison improved median and p95. With 80 observations per arm nearest-rank p99 is the maximum. The largest observed stall increased.

Source alpha determines the visible rectangle for each hull-facing and shell-facing texture. One texel of margin preserves support for linear filtering. The original per-facing fallback still draws full quads on drivers without atlas shader support. Matched 1280×720 framebuffer PNGs at ticks 90 and 94 have respectively 272 and 270 changed pixels out of 921,600. Largest absolute channel differences were 2/255 and 1/255. Both trials reached tick 94 with 986 hits and fingerprint 38e28a84564f48fd. See png-sha256.txt.

The diagnostic p2hull.log forces GPU completion between passes, which changes pacing. Over 42 measured frames its per-pass medians were smoke 0.97 ms, additive glow 7.25, normal shield art 53.46, shield recharge 2.52, lit hull surfaces 23.29, weapon FX 46.71, sky 35.07. Independent diagnostic timings should not be summed into the measured frame percentile.

To reproduce, build the repository with JDK 17 and the packaged desktop runtime resources. Run the manual :desktop:combatFrameBenchmark task on the original and candidate commits. For the alternating experiment run prepare_interleaved.py CANDIDATE_REPO TEMP_SOURCE_DIR, compile its two generated Java sources against the game and desktop runtime classes, and put those temporary classes first on the runtime classpath. Launch diplomacy.desktop.DesktopFrameBenchmark with -Dbench.warm=40 -Dbench.frames=160. The standalone original and candidate logs use 18 warmup + 80 measured frames and contain the screenshot CRCs. Each run must end with a changing tick and matching scenario state.

## Authored laser frames

Above the shield optimization, commit aafaa361ad11f053b4c28c289d370455fcad0b0b trims laser quads to the active frame's true alpha bounds. The build computes separate full- and mobile-resolution bounds from their actual PNGs, including the one-texel footprint outside each atlas cell that linear filtering can sample. The fallback is the full original frame. The ten original desktop and ten actual bicubic mobile derivatives produced 976 per-frame extent records. An independent Pillow scan matched all 976 exactly. The laser GPU images and source-art contents are unchanged.

At tick 90+, the laser-only phase was the dominant weapon effect in the baseline: 168 authored laser events active at median, with separately GL-completed median 51.65 ms laser submission plus completion and 7.82 ms for the rest of weapon FX. These synchronized software-GL numbers are diagnostic and host-load dependent.

With shield cropping active on both sides, the laser A/B used 40 warmup then 160 balanced frames, 80 per path. Original full cells vs clipped cells through GL completion: p50 308.963 to 253.760 ms; p95 498.426 to 496.359; p99 620.529 to 1,113.108. Submission p50 59.135 to 63.600 and p95 149.161 to 233.502. At 80 observations per arm p99 is the maximum. The clipped laser path improved median completion, with no evidence of a tail-time improvement in this test. Both variants share one advancing simulation from tick 90, 968 hits, to tick 100, 1066 hits and fingerprint 6cf048e24cd3294b. Use prepare_laser_interleaved.py like the shield generator, with shipped bounds files available to the runtime.

At ticks 90 and 94, independent full-frame comparisons of shield cropping vs shield+laser cropping changed 381 and 707 pixels out of 921,600 respectively, each with a maximum per-channel difference of two 8-bit units. The independent process runs end at tick 94, 986 hits, fingerprint 38e28a84564f48fd.

The surfaceless EGL tests in gles compare the entire shield atlas quad with its guarded source-alpha cutout for all eight atlas slots at four angles/scales including clipped viewport boundaries. Tests use genuine linear filtering and blending and both states of the recharge scan, across 64 draws per context. The ES 2.0 and ES 3.0 fixtures each changed 13 of 262,144 pixels in total, with a maximum one-unit channel difference.

## Integrated pass-level diagnosis

The integrated candidate source tree was 0d7e424fc6daedb6a3c0a17173a24f3d7bd34c81; its core, game, server and desktop sources match squashed 360f537. The standalone baseline for this pair was aec40264e909489083d292a499eca0b8fc7e0190. Each run used 18 warmup and 60 measured frames under the same deterministic inputs. Both reached tick 93 / fingerprint 1723ce7f8774026d / 982 hits. The marker hud contains fog rendering, sensor overlays and HUD. simAudio includes simulation, effects advancement and audio; most frames between physics steps. The nested shield/material and laser timers overlap their containing pass. Timers force GL completion, add CPU logging overhead and disrupt natural CPU/GPU overlap. Separate baseline and candidate runs had different external host load. Use the integrated stage medians for prioritization, the interleaved A/B for improvements.

The integrated fleet's largest rendering passes were hulls plus shields (30.17 ms p50, including 12.96 ms lit hulls and 11.59 ms shield art), moving procedural sky (22.88 ms), and fog/sensors/HUD (14.09 ms). Weapon FX p50 was 5.86 ms including the authored lasers at 3.71 ms. Additive glow took 4.30 ms and smoke 0.17 ms. The comparison and full logs are in combined-stage-ms.csv and p2profile-*.log.

### Both geometry changes on one integrated scene

The combined interleaved comparison leaves the current sky, simulation and all other game logic active in both cases. Alternate original full shield and laser quads versus both cropped variants with the same ABBA assignment above. There were 40 warmup plus 240 measured real-GL frames, 120 per geometry path. Tick 90 advanced to 104, 968 hits to 1,114, ending fingerprint 5e342d04a6ca98ac. Completed-frame p50/p95/p99 were 160.439 / 372.917 / 428.594 ms with full quads and 116.408 / 287.145 / 369.137 ms with cropped quads. CPU submission was 26.189 / 151.410 / 360.759 versus 25.122 / 183.298 / 339.536 ms. Absolute timings reflect this host session. For reproduction generate both temporary switches and assign both trialCropped flags the same value in the fixture; set bench.warm=40 and bench.frames=240. See p2bothbalanced.log.

## Moving-sky and fog diagnosis on the integrated build

The diagnostic overlays add GL completion markers to the game sources at 360f537. The scenario uses the 400-ship tick-90 seed from the completed-frame benchmark. The original camera still moves during this sequence. The normal overview yielded 95 measured frames including 93 freshly drawn skies, ending at tick 95 with 989 hits. The strategic view yielded 52 measured frames including 44 freshly drawn skies, ending at tick 93 with 982 hits. Sky timings exclude stationary cache hits. Medians are in milliseconds on the local 1280×720 Mesa software-rendered client. The hull rows are observations at two actual zooms, each drawing different screen areas, so they cannot isolate material-shader cost.

| GL-completed stage | Normal overview, lit hulls (1.11×) | Strategic view, flat hulls (4.41×) |
|---|---:|---:|
| Moving fullscreen nebula shader | 20.453 | 27.745 |
| Stars | 0.494 | 11.564 |
| Hull surfaces | 12.015 | 6.652 |
| Regular shield layers | 12.662 | 6.250 |
| Fog-mask texture compositing | 6.788 | 11.505 |
| Sensor overlays | 1.736 | 3.865 |
| HUD | 2.518 | 4.001 |

Fog-mask rebuild and upload occurred on 3 of 95 overview frames (36.215 ms median, 60.952 maximum) and 5 of 52 strategic frames (1.813 ms median, 53.240 maximum). Small counts and host load limit interpretation of these measurements. The raw split scopes and nearest-rank percentiles are in `p2deep-*.log` and `deep-*.csv`.

The next testable improvement is to scissor the moving nebula draw to the single rectangle around all non-opaque texels of the same frame's existing fog mask. In a passive coverage check that expanded this rectangle by one mask texel for bilinear filtering, 20.00% of full-screen pixels lay outside the rectangle at overview tick 90. At strategic ticks 90 through 92 the fraction was 90.56%. This measures redundant full-screen coverage. Actual frame savings require an A/B. The two coverage runs ended on tick 92 with identical fingerprint `9350cd6f6fae591c` and 978 hits. See `p2aabb-*.log`. A candidate would prepare the existing visibility mask before drawing, maintain the full sky geometry, respect active viewport pixel scaling and leave the stationary sky cache fully populated. Non-fogged views still require the complete sky.

## Independent 32-ship live frame pacing

Each process runs the real 16v16 escort with vsync off and the camera moving. Starting at the first engaged tick, 127, the initial state fingerprint was `0b1a7631cbd3662e` with one hit, 32 missiles and 50 ballistics. A fresh JVM and fresh Xvfb display ran 48 warmup and 180 measured frames, four processes each for aec4026 and 360f537 in A-B-B-A then B-A-A-B order. The fixture measures uncapped start-to-start intervals, including the normal desktop swap. The two builds use their own production classes and shader paths. The candidate includes all ten shipping laser bounds tables. The baseline uses its original full laser sprite cells. Final ticks range from 144 to 154 because the simulation uses real elapsed time. Every run saw additional combat hits.

Across 720 samples per revision, baseline/candidate p50 was 24.902/26.781 ms, p95 was 77.100/66.559 ms, and p99 was 184.859/201.588 ms. All 1,440 intervals exceeded the 16.67 ms budget. Pooled median and p99 increased. The candidate's four adjacent-pair medians changed by −10.9%, +34.5%, −6.6% and −1.8%. Host load varied substantially across runs, and the test supplies no consistent small-skirmish improvement. The separate hosted test had 101/320 baseline and 155/320 candidate over 16.67 ms. Per-process local percentiles, counts, state endpoints, raw timings and configuration are in `live-32/`.
