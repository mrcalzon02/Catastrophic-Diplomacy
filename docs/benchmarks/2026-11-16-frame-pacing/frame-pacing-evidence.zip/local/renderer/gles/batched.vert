#ifdef GL_ES
#define ATLAS_COORD highp
#else
#define ATLAS_COORD
#endif
attribute vec4 a_position;
attribute vec4 a_color;
attribute vec2 a_texCoord0;
uniform mat4 u_projTrans;
varying vec4 v_color;
varying vec2 v_uv;
varying ATLAS_COORD vec2 v_atlas; varying ATLAS_COORD vec4 v_limits;
void main(){
    v_color=a_color;
    v_color.a*=255.0/254.0;
    gl_Position=u_projTrans*a_position;
    float layer=floor(a_texCoord0.x*0.5);
    v_uv=vec2(a_texCoord0.x-2.0*layer,a_texCoord0.y);
    float face=mod(layer,4.0);
    vec2 size=vec2(192.0,layer<4.0 ? 192.0 : 288.0);
    vec2 first=vec2(0.0), span=size;
    vec2 origin=vec2(0.0,layer<4.0 ? 0.0 : 194.0);
    if(face<0.5){
        span.y=size.y*0.5+1.0;
    }else if(face<1.5){
        origin.x=192.0;
        span.x=97.0;
    }else if(face<2.5){
        origin.y+=size.y*0.5+1.0;
        first.y=size.y*0.5-1.0;
        span.y=size.y*0.5+1.0;
    }else{
        origin.x=289.0;
        first.x=95.0;
        span.x=97.0;
    }
    vec2 sheet=vec2(386.0,484.0);
    v_atlas=(origin+v_uv*size-first)/sheet;
    v_limits=vec4((origin+0.5)/sheet,(origin+span-0.5)/sheet);
}
