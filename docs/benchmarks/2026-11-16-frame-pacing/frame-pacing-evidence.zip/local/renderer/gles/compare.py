"""Compile and draw with both runtime shader pairs on a real offscreen ES 2.0 context."""
import ctypes as C, hashlib, os, pathlib
os.environ.update(EGL_PLATFORM='surfaceless', MESA_GLES_VERSION_OVERRIDE=os.getenv('TEST_ES','2.0'), LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='1')
E=C.CDLL('libEGL.so.1')
P=C.c_void_p; I=C.c_int; U=C.c_uint; F=C.c_float; S=C.c_char_p; B=C.c_ubyte
def egl(name, result, *args):
    f=getattr(E,name); f.restype=result; f.argtypes=args; return f
def ints(*v): return (I*len(v))(*v)
get=egl('eglGetProcAddress',P,S)
d=egl('eglGetDisplay',P,P)(None); assert d
assert egl('eglInitialize',U,P,P,P)(d,None,None)
assert egl('eglBindAPI',U,U)(0x30a0)
cfg=P(); count=I()
assert egl('eglChooseConfig',U,P,P,P,I,P)(d,ints(0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038),C.byref(cfg),1,C.byref(count)) and count.value
surf=egl('eglCreatePbufferSurface',P,P,P,P)(d,cfg,ints(0x3057,64,0x3056,64,0x3038))
ctx=egl('eglCreateContext',P,P,P,P,P)(d,cfg,None,ints(0x3098,int(os.environ.get('TEST_ES','2.0')[0]),0x3038))
assert surf and ctx and egl('eglMakeCurrent',U,P,P,P,P)(d,surf,surf,ctx)
def gl(name,result,*args):
    return C.CFUNCTYPE(result,*args)(get(('gl'+name).encode()))
def gs(name): return gl('GetString',S,U)(name).decode()
print(gs(0x1f02),gs(0x1f01))
def program(prefix):
    p=gl('CreateProgram',U)()
    for ext,typ in [('vert',0x8b31),('frag',0x8b30)]:
        sh=gl('CreateShader',U,U)(typ); src=S(pathlib.Path(prefix+'.'+ext).read_bytes())
        gl('ShaderSource',None,U,I,P,P)(sh,1,C.byref(src),None)
        gl('CompileShader',None,U)(sh); ok=I()
        gl('GetShaderiv',None,U,U,P)(sh,0x8b81,C.byref(ok)); buf=C.create_string_buffer(8192)
        gl('GetShaderInfoLog',None,U,I,P,P)(sh,len(buf),None,buf); assert ok.value,buf.value
        gl('AttachShader',None,U,U)(p,sh)
    gl('LinkProgram',None,U)(p); ok=I(); gl('GetProgramiv',None,U,U,P)(p,0x8b82,C.byref(ok))
    buf=C.create_string_buffer(8192); gl('GetProgramInfoLog',None,U,I,P,P)(p,len(buf),None,buf); assert ok.value,buf.value
    return p
def sample(cropped):
    prefix="batched"
    p=program(prefix); gl('UseProgram',None,U)(p)
    uniform=lambda s:gl('GetUniformLocation',I,U,S)(p,s.encode())
    gl('UniformMatrix4fv',None,I,I,B,P)(uniform('u_projTrans'),1,0,(F*16)(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1))
    gl('Uniform1i',None,I,I)(uniform('u_texture'),0)
    gl('Uniform1f',None,I,F)(uniform('u_tick'),42)
    import numpy as np
    ids=(U*9)(); gl('GenTextures',None,I,P)(9,ids)
    def texture(id,pixels):
        gl('BindTexture',None,U,U)(0xde1,id)
        h,w,_=pixels.shape
        gl('TexImage2D',None,U,I,I,I,I,U,U,P)(0xde1,0,0x1908,w,h,0,0x1908,0x1401,S(pixels.tobytes()))
        for k in [0x2800,0x2801]: gl('TexParameteri',None,U,U,I)(0xde1,k,0x2601)
        for k in [0x2802,0x2803]: gl('TexParameteri',None,U,U,I)(0xde1,k,0x812f)
    sheet=np.zeros((484,386,4),dtype=np.uint8)
    boxes=[]
    for layer in range(8):
        w,h=192,192 if layer<4 else 288
        face=layer%4; row=0 if layer<4 else 194
        y,x=np.indices((h,w))
        a=np.zeros((h,w,4),dtype=np.uint8)
        for ch in range(4): a[:,:,ch]=(45+layer*19+ch*17+x//4+y//4)%256
        # Include edge-touching sectors, internal holes, isolated one-alpha
        # texels and asymmetrical silhouettes in both slot rows of the sheet.
        a[(x < (layer+1)*4) | (y < layer*3) | (x+y > w+h-14)]=0
        a[(x%23<3)&(y%17<4)]=0
        a[h//6,w//3,3]=1
        if face==0:
            a[h//2:]=0; sheet[row:row+h//2+1,0:w]=a[:h//2+1]
        elif face==1:
            a[:,w//2:]=0; sheet[row:row+h,192:289]=a[:,:97]
        elif face==2:
            a[:h//2]=0; sheet[row+h//2+1:row+h+2,0:w]=a[h//2-1:]
        else:
            a[:,:w//2]=0; sheet[row:row+h,289:386]=a[:,95:]
        ys,xs=np.where(a[:,:,3]>0)
        boxes.append((max(0,min(xs)-1)/w,max(0,min(ys)-1)/h,
                      min(w,max(xs)+2)/w,min(h,max(ys)+2)/h))
        texture(ids[layer],a)
    texture(ids[8],sheet)
    attrib=lambda s:gl('GetAttribLocation',I,U,S)(p,s.encode())
    color=attrib('a_color');gl('VertexAttrib4f',None,U,F,F,F,F)(color,.4,.8,.6,.8)
    pos=attrib('a_position'); uv=attrib('a_texCoord0')
    for loc in [pos,uv]:gl('EnableVertexAttribArray',None,U)(loc)
    buffers=(U*2)();gl('GenBuffers',None,I,P)(2,buffers)
    def upload(id,loc,values):
        arr=(F*len(values))(*values)
        gl('BindBuffer',None,U,U)(0x8892,id)
        gl('BufferData',None,U,C.c_ssize_t,P,U)(0x8892,C.sizeof(arr),arr,0x88e0)
        gl('VertexAttribPointer',None,U,I,U,B,I,P)(loc,2,0x1406,0,0,None)
    gl('Enable',None,U)(0x0BE2)
    gl('BlendFunc',None,U,U)(0x0302,0x0303)
    frames=[]
    import math
    for scan in (0,1):
        gl('Uniform1f',None,I,F)(uniform('u_scan'),scan)
        for scale,angle,pan in [(0.39,0,0),(0.91,34,0.13),(1.64,137,-0.1),(0.13,279,0.7)]:
            rad=math.radians(angle); c=math.cos(rad);d=math.sin(rad)
            for layer in range(8):
                gl('ClearColor',None,F,F,F,F)(0.12,0.25,0.31,1)
                gl('Clear',None,U)(0x4000)
                l,t,r,b=boxes[layer] if cropped else (0,0,1,1)
                coords=[];uvs=[]
                for u,v in ((l,t),(r,t),(l,b),(r,b)):
                    x=(2*u-1)*scale; y=(2*v-1)*scale*0.77
                    coords.extend((x*c-y*d+pan,x*d+y*c-0.06))
                    uvs.extend((2*layer+u,v))
                upload(buffers[0],pos,coords);upload(buffers[1],uv,uvs)
                gl('DrawArrays',None,U,I,I)(5,0,4)
                pix=(B*(64*64*4))()
                gl('ReadPixels',None,I,I,I,I,U,U,P)(0,0,64,64,0x1908,0x1401,pix)
                assert gl('GetError',U)()==0
                frames.append(bytes(pix))
    return frames
import numpy as np
before=sample(False);after=sample(True)
assert len(before)==64 and len(set(before))>32
diff=np.abs(np.frombuffer(b''.join(before),dtype=np.uint8).astype('int16')-
            np.frombuffer(b''.join(after),dtype=np.uint8).astype('int16')).reshape((-1,4))
print('frames',len(before),'max_channel_delta',int(diff.max()),'changed_pixels',
      int((diff.max(axis=1)>0).sum()),'total_pixels',len(diff))
assert diff.max()<=2
print('PASS shield geometry across eight regions, four rotations/scales, scan off/on')
