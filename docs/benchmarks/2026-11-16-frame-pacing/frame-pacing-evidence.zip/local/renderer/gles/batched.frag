#ifdef GL_ES
#define ATLAS_COORD highp
#else
#define ATLAS_COORD
#endif
#ifdef GL_ES
precision mediump float;
#endif
varying vec4 v_color;
varying vec2 v_uv;
uniform sampler2D u_texture;
uniform float u_scan;
uniform float u_tick;
varying ATLAS_COORD vec2 v_atlas;
varying ATLAS_COORD vec4 v_limits;
void main(){
    vec4 source=texture2D(u_texture,clamp(v_atlas,v_limits.xy,v_limits.zw));
    float pattern=max(source.r,max(source.g,source.b));
    vec3 color=v_color.rgb*(0.43+0.73*pattern);
    float alpha=source.a*v_color.a;
    if(u_scan>0.5){
        float wave=fract(v_uv.x*.92+v_uv.y*.38-u_tick*.014);
        float lit=1.0-smoothstep(0.0,.23,abs(wave-.5));
        alpha*=lit;color=min(vec3(1.0),color*1.35);
    }
    gl_FragColor=vec4(min(vec3(1.0),color),alpha);
}
