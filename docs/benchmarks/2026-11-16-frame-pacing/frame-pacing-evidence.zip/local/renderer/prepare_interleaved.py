"""Produce optional benchmark-only sources selecting full or trimmed quads each frame."""
from argparse import ArgumentParser
from pathlib import Path
ap=ArgumentParser()
ap.add_argument("repository",type=Path)
ap.add_argument("out",type=Path)
args=ap.parse_args()
client=args.repository / "game/src/main/java/diplomacy/client/TerranPlaceholderSprites.java"
fixture=args.repository / "desktop/src/test/java/diplomacy/desktop/DesktopFrameBenchmark.java"
s=client.read_text()
a="    private void drawShieldLayer("
assert s.count(a)==1
s=s.replace(a,"    public static boolean trialCropped=true;\n"+a)
b="        ShieldSlice slice=sectors.slices[layer];"
assert s.count(b)==1
s=s.replace(b,"""        if(!trialCropped){
            Texture sheet=sectors.atlas;
            batch.draw(sheet,pose.x()-width/2,pose.y()-height/2,
                    width/2,height/2,width,height,1,1,rotation,
                    2*layer*sheet.getWidth(),0,sheet.getWidth(),sheet.getHeight(),false,false);
            return;
        }
"""+b)
args.out.mkdir(parents=True,exist_ok=True)
(args.out / client.name).write_text(s)
s=fixture.read_text()
a="        if(profiler!=null)profiler.reset();"
assert s.count(a)==1
s=s.replace(a,"        diplomacy.client.TerranPlaceholderSprites.trialCropped=(index%4==1||index%4==2)^(index/20%2==1);\n"+a)
(args.out / fixture.name).write_text(s)
