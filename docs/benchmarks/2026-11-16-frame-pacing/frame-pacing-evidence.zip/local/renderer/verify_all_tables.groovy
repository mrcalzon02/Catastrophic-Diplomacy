// Offline bounds for laser quads. Include adjacent sheet pixels because a linearly
// filtered sample at a cell boundary can see the neighboring animation frame.
@groovy.transform.CompileStatic
static void writeLaserFrameBounds(java.awt.image.BufferedImage image, int frameCount,
                                 File output) {
    int w=Math.floorDiv(image.width,8)
    int h=Math.floorDiv(w*160,512)
    int[] row=new int[w+2]
    def stream=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(output)))
    try {
        stream.writeInt(w)
        stream.writeInt(h)
        for(int i=0;i<frameCount;i++){
            int originX=(i%8)*w,originY=Math.floorDiv(i,8)*h
            int startX=Math.max(0,originX-1),endX=Math.min(image.width,originX+w+1)
            int startY=Math.max(0,originY-1),endY=Math.min(image.height,originY+h+1)
            int minX=w,minY=h,maxX=-1,maxY=-1
            for(int y=startY;y<endY;y++){
                image.getRGB(startX,y,endX-startX,1,row,0,endX-startX)
                for(int x=startX;x<endX;x++){
                    if((row[x-startX]>>>24)==0)continue
                    minX=Math.min(minX,x-originX)
                    minY=Math.min(minY,y-originY)
                    maxX=Math.max(maxX,x-originX)
                    maxY=Math.max(maxY,y-originY)
                }
            }
            if(maxX<minX||maxY<minY){stream.writeLong(0L);continue}
            int left=Math.max(0,Math.min(w-1,minX-1)),top=Math.max(0,Math.min(h-1,minY-1))
            int right=Math.min(w,Math.max(left+1,maxX+2)),bottom=Math.min(h,Math.max(top+1,maxY+2))
            stream.writeShort(left)
            stream.writeShort(top)
            stream.writeShort(right-left)
            stream.writeShort(bottom-top)
        }
    } finally {stream.close()}
}



new File(args[0],'frames.txt').eachLine { line ->
    def (file,frames)=line.tokenize()
    def image=javax.imageio.ImageIO.read(new File(args[0],file))
    writeLaserFrameBounds(image,frames as int,new File(args[0],file+'.bounds'))
    def reduced=new java.awt.image.BufferedImage(image.width.intdiv(2),image.height.intdiv(2),java.awt.image.BufferedImage.TYPE_INT_ARGB)
    def graphics=reduced.createGraphics()
    graphics.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BICUBIC)
    graphics.drawImage(image,0,0,reduced.width,reduced.height,null)
    graphics.dispose()
    javax.imageio.ImageIO.write(reduced,'png',new File(args[0],file+'.mobile.png'))
    writeLaserFrameBounds(reduced,frames as int,new File(args[0],file+'.mobile.bounds'))
}
