CATastrophic Diplomacy — Stage 1 approved runtime artwork

Contains 10 Terran vessel sprites, 35 isolated continuous beam FX (5 colors x 7 variants), and 3 damage/shield material images. All are PNG RGBA or palette PNG ready for libGDX. Never combine physical emitter art into beam sprites.

INSTALL: extract this archive into the root of mrcalzon02/Catastrophic-Diplomacy, retaining the assets/ paths. Commit the 48 image files with Git and push. Three material PNGs are already committed upstream; unmodified matching copies are safe. Runtime code and source archive importer were committed separately.

VERIFY: compare each local PNG SHA256 against runtime-art-manifest.json. Approved alien lineup images are still concept art and require individual extraction and anchor registration. The 23 module source sheets are archived, not individually approved for mounting.
