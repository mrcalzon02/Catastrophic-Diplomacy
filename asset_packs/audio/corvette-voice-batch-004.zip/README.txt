Catastrophic Diplomacy CORVETTE voice - Batch 004
26 clips at 24kHz mono: OGG runtime + PCM WAV edits. The MP3 master is preserved.
Please audit script alignment before publishing a public release.
