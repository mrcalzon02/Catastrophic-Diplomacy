LIGHT_CRUISER VOICE RECORDING — BATCH 011

Original: Light cruiser.mp3 — preserved unchanged.
26 WAV editing clips and 26 OGG game clips; manifest.csv/json label audio in script order.
Do not treat assigned text as independently transcribed speech.
Original recording has been segmented acoustically; review exact dialogue alignment by listening.

GitHub payload from Drive readback: game OGG ZIP.
