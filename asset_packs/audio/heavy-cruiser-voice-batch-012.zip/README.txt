HEAVY CRUISER VOICE RECORDING — BATCH 012

Original: heavy crusiervoiced.mp3 — preserved unchanged.
26 WAV editing clips and 26 OGG game clips; manifest.csv/json label script-order cues.
Do not treat assigned text as independently transcribed speech.
The first voice line includes a dramatic pause; short intra-line pauses near 48–54 and 95–101 seconds remain intact.
Two closely timed end lines near 127–137 and 138–147 seconds are separated at acoustic pauses.
Google Drive upload must PRECEDE GitHub binary upload.
