Catastrophic Diplomacy — announcer voice pack, Batch 001

30 cues, sliced from the supplied continuous recording using the audible pauses.

ogg/: Game-friendly Ogg Vorbis mono assets (use these in packaged builds).
wav/: Uncompressed PCM assets for further sound editing.
manifest.json / manifest.csv: script, IDs, exact source timecodes, usage suggestions.
source_unchanged.mp3: Unmodified original for provenance.

Note: Script labels were assigned in the same order as the 30-line supplied script. The
recording was segmented acoustically, not independently speech-recognized. Check
individual clips before publishing if the spoken wording deviates from the script.

Do not use these to voice individual ships; ship communications remain text-only.
Humorous cues are rare optional announcer announcements.
