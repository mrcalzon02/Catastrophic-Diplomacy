Catastrophic Diplomacy — Fighter Voice Batch 003
26 separate recordings, 13 gameplay events with two variants each.
Master keeps original MP3. OGG runtime package is intended for libGDX Android/Desktop.
Text-line assignments follow recording order; audit spoken wording before release.
Gameplay should use only matched interceptor / fighter cockpit text lines, never carrier-bridge lines.
